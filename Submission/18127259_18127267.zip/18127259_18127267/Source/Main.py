from Graphic import *

app = Graphic()
app.run()
